from rest_framework import serializers
from api.models import Author, Category, Book


class AuthorSerializer(serializers.ModelSerializer):

    class Meta:
        model = Author
        fields = ["id","name"]

    def to_representation(self, value):
        return value.name



class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id","category_name"]

    def to_representation(self, value):
        return value.category_name


class BookSerializer(serializers.ModelSerializer):
    authors = AuthorSerializer(many=True)
    categories = CategorySerializer(many=True)
    class Meta:
        model = Book
        fields = ['title','authors','published_date','categories','average_rating','ratings_count','thumbnail']

    def create(self, validated_data):
        authors_data = validated_data.pop('authors')
        categories_data = validated_data.pop('categories')
        book = Book.objects.create(**validated_data)

        for book_d in authors_data:
            Author.objects.create(book=book, **book_d)
        for book_d in categories_data:
            Category.objects.create(book=book, **book_d )

        return book

