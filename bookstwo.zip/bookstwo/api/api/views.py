from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.filters import OrderingFilter, SearchFilter

from api.models import Author, Category, Book
from .serializer import BookSerializer, AuthorSerializer, CategorySerializer


class BookViewSet(viewsets.ModelViewSet):
    serializer_class = BookSerializer
    filter_backends = [OrderingFilter, SearchFilter]
    ordering_fields = ['published_date']

    def get_queryset(self):

        published_date = self.request.query_params.get('published_date')
        if published_date is not None:
            queryset = Book.objects.all()
            queryset = queryset.filter(published_date=published_date)
            return queryset

        author_name = self.request.query_params.get('author')
        if author_name is not None:
            print(author_name)
            queryset = Book.objects.filter(authors__name = author_name)
            return queryset

        book = Book.objects.all()
        return book

    def create(self, request, *args, **kwargs):
        data = request.data
        new_book = Book.objects.create(title = data["title"], published_date=data["published_date"], average_rating=data["average_rating"],ratings_count=data["ratings_count"],thumbnail=data["thumbnail"])
        new_book.save()

        for author_data in data["authors"]:
            author_obj = Author.objects.get(name=author_data)
            new_book.authors.add(author_obj)

        for category_data in data["categories"]:
            category_obj = Category.objects.get(category_name=category_data)
            new_book.categories.add(category_obj)

        serializer = BookSerializer(new_book)

        return Response(serializer.data)


class AuthorViewSet(viewsets.ModelViewSet):
    queryset = Author.objects.all()
    serializer_class = AuthorSerializer

    # can paste in multiple authors in the list
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data, many=isinstance(request.data, list))
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)


class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

    # can paste in multiple authors in the list
    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data, many=isinstance(request.data, list))
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)


