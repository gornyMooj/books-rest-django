from django.conf.urls import url, include
from .views import BookViewSet, AuthorViewSet, CategoryViewSet
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register("books",BookViewSet, basename="books")
router.register("author",AuthorViewSet, basename="author")
router.register("category",CategoryViewSet, basename="category")


urlpatterns = [
    url('',include(router.urls))
]