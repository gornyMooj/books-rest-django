from django.db import models


class Author(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Category(models.Model):
    category_name = models.CharField(max_length=50)

    def __str__(self):
        return self.category_name


class Book(models.Model):
    title = models.CharField(max_length=200)
    authors = models.ManyToManyField(Author)
    published_date = models.CharField(max_length=50)
    categories = models.ManyToManyField(Category)
    average_rating = models.IntegerField()
    ratings_count = models.IntegerField()
    thumbnail = models.CharField(max_length=300)


    def __str__(self):
        return self.title
